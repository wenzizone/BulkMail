<?php
$optionalModuleStrings = array(
		'CustomerPortal_description'=>'管理接口来控制客户门户插件的行为',
		'FieldFormulas_description'=>'为自定义字段设置规则以保存更新记录值',
		'RecycleBin_description'=>'模块管理已删除的记录，提供完全恢复或删除的能力',
		'Tooltip_description'=>'为一个字段配置工具提示显示，它可以是其他字段的组合',
		'Webforms_description'=>'服务器端支持，允许建立客户的WebForms轻松捕捉信息',
	);
?>